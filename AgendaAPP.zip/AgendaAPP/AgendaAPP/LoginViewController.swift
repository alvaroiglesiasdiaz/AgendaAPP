//
//  ViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/1/21.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var TFEmail: UITextField!
    @IBOutlet weak var TFPassword: UITextField!
    @IBOutlet weak var BTNLogin: UIButton!
    @IBOutlet weak var StackView: UIStackView!
    @IBOutlet weak var LBReset: UILabel!
    @IBOutlet weak var LBRegister: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Set circular corners
        BTNLogin.layer.cornerRadius = 20.0
        TFEmail.layer.cornerRadius = 25.0
        TFPassword.layer.cornerRadius = 25.0
        TFEmail.layer.borderColor = UIColor.black.cgColor
        TFPassword.layer.borderColor = UIColor.black.cgColor


        
    }


}

